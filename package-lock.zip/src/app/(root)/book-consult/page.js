"use client";
import { useState } from "react";
import {
  Mail,
  Phone,
  User,
  Calendar,
  Clock,
  MapPin,
  MessageSquare,
} from "lucide-react";
import AppointmentFormField from "@/components/pages/AppointmentFormField";

const indianCities = [
  "Mumbai", "Delhi", "Bengaluru", "Hyderabad", "Chennai", "Kolkata",
  "Pune", "Ahmedabad", "Jaipur", "Lucknow", "Chandigarh", "Bhopal",
  "Indore", "Nagpur", "Surat", "Patna", "Ranchi", "Guwahati",
  "Bhubaneswar", "Kochi", "Thiruvananthapuram", "Coimbatore", "Mysuru",
  "Mangalore", "Visakhapatnam", "Vijayawada", "Raipur", "Dehradun",
  "Shimla", "Jammu", "Srinagar", "Amritsar", "Ludhiana", "Agra",
  "Varanasi", "Kanpur", "Noida", "Gurgaon", "Faridabad", "Ghaziabad",
  "Udaipur", "Jodhpur", "Kota", "Gwalior", "Jabalpur", "Nashik",
  "Aurangabad", "Kolhapur", "Solapur", "Vadodara", "Rajkot",
];

const inputCls =
  "w-full pl-10 border border-gray-300 rounded-lg px-4 py-3 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none";
const selectCls =
  "w-full pl-10 border border-gray-300 rounded-lg px-4 py-3 bg-white text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none";

const emptyForm = {
  name: "",
  phone: "",
  email: "",
  date: "",
  visit: "",
  city: "",
  notes: "",
};

export default function BookConsult() {
  const [formData, setFormData] = useState(emptyForm);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("/api/book-consult", {
        method: "POST",
        body: JSON.stringify(formData),
        headers: { "Content-Type": "application/json" },
      });
      const result = await response.json();
      if (result.success) {
        alert("Appointment booked successfully!");
        setFormData(emptyForm);
      } else {
        alert("Failed to book. Please try again.");
      }
    } catch {
      alert("Something went wrong. Try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="min-h-screen flex items-center justify-center bg-linear-to-b from-blue-50 via-white to-blue-50 px-4 py-12">
      <div className="w-full max-w-2xl">
        <div className="text-center md:mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Book Your Appointment
          </h2>
          <p className="text-gray-600 text-base md:text-lg">
            Fill in your details and we&apos;ll confirm your appointment shortly.
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="md:bg-white rounded-2xl p-6 sm:p-8 md:border md:border-gray-200 md:shadow-md space-y-4 md:space-y-6"
        >
          <AppointmentFormField label="Full Name" required icon={User}>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              placeholder="John Doe"
              className={inputCls}
            />
          </AppointmentFormField>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <AppointmentFormField label="Phone Number" required icon={Phone}>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                placeholder="+91 92179 58539"
                className={inputCls}
              />
            </AppointmentFormField>
            <AppointmentFormField label="Email Address" icon={Mail}>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                className={inputCls}
              />
            </AppointmentFormField>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <AppointmentFormField label="Preferred Date" icon={Calendar}>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                min={new Date().toISOString().split("T")[0]}
                className={inputCls}
              />
            </AppointmentFormField>
            <AppointmentFormField label="When do you plan for hair transplant?" icon={Clock}>
              <select
                name="visit"
                value={formData.visit}
                onChange={handleChange}
                className={selectCls}
              >
                <option value="within week">Within a week</option>
                <option value="within month">Within a month</option>
                <option value="next 2-3 month">Next 2-3 months</option>
                <option value="not sure">Not Sure</option>
              </select>
            </AppointmentFormField>
          </div>

          <AppointmentFormField label="Select City" required icon={MapPin}>
            <select
              name="city"
              value={formData.city}
              onChange={handleChange}
              required
              className={selectCls}
            >
              <option value="">Choose a city</option>
              {indianCities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </AppointmentFormField>

          <AppointmentFormField label="Notes / Concerns" icon={MessageSquare}>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              placeholder="Any special concerns..."
              rows="3"
              className={inputCls}
            />
          </AppointmentFormField>

          <button
            type="submit"
            disabled={loading}
            className={`w-full py-3 md:py-4 rounded-lg font-semibold text-white text-lg transition-all duration-300 ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:ring-blue-300"
            }`}
          >
            {loading ? "Processing..." : "Book Appointment"}
          </button>

          <p className="text-xs text-gray-500 text-center">
            Your details are safe with us. We never share your information.
          </p>
        </form>
      </div>
    </section>
  );
}
